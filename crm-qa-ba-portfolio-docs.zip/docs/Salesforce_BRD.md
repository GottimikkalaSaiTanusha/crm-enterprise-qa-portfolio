# Salesforce BRD Sample

This document provides business requirements for Salesforce Health Cloud features.