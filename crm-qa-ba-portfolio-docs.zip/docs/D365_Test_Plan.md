# Dynamics 365 Test Plan

This document outlines the test strategy and scope for testing Dynamics 365 CRM modules.