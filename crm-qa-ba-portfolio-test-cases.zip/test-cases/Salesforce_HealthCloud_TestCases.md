# Health Cloud Test Cases

1. Validate patient profile creation.
2. Verify care plan associations.