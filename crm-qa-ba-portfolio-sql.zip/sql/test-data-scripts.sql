-- Insert Test Data
INSERT INTO Contacts (FirstName, LastName) VALUES ('John', 'Doe');