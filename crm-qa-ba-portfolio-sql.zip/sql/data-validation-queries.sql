-- Sample SQL Queries
SELECT * FROM Accounts WHERE Email IS NOT NULL;