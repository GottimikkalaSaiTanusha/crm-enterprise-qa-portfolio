# API Test Instructions

Import Postman_Collection.json into Postman to run basic CRM API tests.