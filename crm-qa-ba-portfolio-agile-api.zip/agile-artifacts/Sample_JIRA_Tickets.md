# Sample JIRA Tickets

- CRM-101: Contact module fails to save with optional field empty.