# User Stories

- As a user, I want to create a contact so I can track customer info.