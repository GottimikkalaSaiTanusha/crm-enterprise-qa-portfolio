# Acceptance Criteria

- Contact is created only when all required fields are provided.